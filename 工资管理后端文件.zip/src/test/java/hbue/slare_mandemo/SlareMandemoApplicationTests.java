package hbue.slare_mandemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SlareMandemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
