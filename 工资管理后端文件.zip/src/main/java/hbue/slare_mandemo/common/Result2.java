package hbue.slare_mandemo.common;

public class Result2 {

    private Object data;
    private int total;



}
