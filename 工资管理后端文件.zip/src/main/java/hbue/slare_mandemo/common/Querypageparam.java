package hbue.slare_mandemo.common;


import lombok.Data;

import java.util.HashMap;

@Data
public class Querypageparam {
    //默认参数
   private  static  int PAGE_SIZE =5;
   private  static  int PAGE_NUM=1;

//添加默认值
    private  int pagenum=PAGE_SIZE;

    private int pagesiz=PAGE_NUM;


//    private HashMap param ;


}
