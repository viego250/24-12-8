package hbue.slare_mandemo.pojo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author author
 * @since 2024-09-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("userinfo")
public class Userinfo implements Serializable {

    private static final long serialVersionUID = 1L;


    private Integer id;

    @TableField("name")
    private String name;

    @TableField("title")
    private String title;

    @TableField("dept")
    private String dept;

    @TableField("slare")
    private Integer slare;


}
