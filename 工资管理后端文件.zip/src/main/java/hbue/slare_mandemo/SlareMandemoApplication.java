package hbue.slare_mandemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SlareMandemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SlareMandemoApplication.class, args);
    }

}
