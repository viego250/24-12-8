package hbue.slare_mandemo.service;

import hbue.slare_mandemo.pojo.Userinfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author author
 * @since 2024-09-18
 */
public interface IUserinfoService extends IService<Userinfo> {

}
