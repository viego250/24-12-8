package hbue.slare_mandemo.service;

import hbue.slare_mandemo.pojo.Dept;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author author
 * @since 2024-11-09
 */
public interface IDeptService extends IService<Dept> {

}
