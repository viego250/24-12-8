package hbue.slare_mandemo.service.serviceimpl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import hbue.slare_mandemo.mapper.UserinfoMapper;
import hbue.slare_mandemo.pojo.Userinfo;
import hbue.slare_mandemo.service.IUserinfoService;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl extends ServiceImpl<UserinfoMapper, Userinfo> implements IUserinfoService {



}
