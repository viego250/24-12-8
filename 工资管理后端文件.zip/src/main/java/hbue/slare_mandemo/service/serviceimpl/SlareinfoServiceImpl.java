package hbue.slare_mandemo.service.serviceimpl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import hbue.slare_mandemo.pojo.Slareinfo;
import hbue.slare_mandemo.mapper.SlareinfoMapper;
import hbue.slare_mandemo.service.ISlareinfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author author
 * @since 2024-11-06
 */
@Service
public class SlareinfoServiceImpl extends ServiceImpl<SlareinfoMapper, Slareinfo> implements ISlareinfoService {

    public void pushSlare(Slareinfo usea, Integer money) {

        int moneyneed =usea.getSlareNeed();
        int remainmoney =moneyneed-money;
        int id =usea.getId();
        if (remainmoney<=0){
            remainmoney=0;
        }
        //发放工资大于需要工资
        if (money>=moneyneed){
              this.lambdaUpdate().set(Slareinfo::getSlareNeed,0)
                      .eq(Slareinfo::getId,id)
                      .set(Slareinfo::getSlareStateI,"已发")
                      .update();
        }
        //发放工资小于需要工资
        else  {

            this.lambdaUpdate().set(Slareinfo::getSlareNeed,remainmoney)
                    .eq(Slareinfo::getId,id)
                    .set(Slareinfo::getSlareStateI,"部分已发")
                    .update();

        }


    }
}
