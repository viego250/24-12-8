package hbue.slare_mandemo.service.serviceimpl;

import hbue.slare_mandemo.pojo.Dept;
import hbue.slare_mandemo.mapper.DeptMapper;
import hbue.slare_mandemo.service.IDeptService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author author
 * @since 2024-11-09
 */
@Service
public class DeptServiceImpl extends ServiceImpl<DeptMapper, Dept> implements IDeptService {

}
