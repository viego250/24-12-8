package hbue.slare_mandemo.mapper;

import hbue.slare_mandemo.pojo.Slareinfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface SlareinfoMapper extends BaseMapper<Slareinfo> {

}
