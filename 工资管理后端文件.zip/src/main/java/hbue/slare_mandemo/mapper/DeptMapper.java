package hbue.slare_mandemo.mapper;

import hbue.slare_mandemo.pojo.Dept;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author author
 * @since 2024-11-09
 */
@Mapper
public interface DeptMapper extends BaseMapper<Dept> {

}
