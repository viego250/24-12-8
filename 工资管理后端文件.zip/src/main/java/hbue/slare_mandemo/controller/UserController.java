package hbue.slare_mandemo.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import hbue.slare_mandemo.common.Querypageparam;
import hbue.slare_mandemo.pojo.Dept;
import hbue.slare_mandemo.pojo.Slareinfo;
import hbue.slare_mandemo.pojo.Userinfo;
import hbue.slare_mandemo.service.serviceimpl.DeptServiceImpl;
import hbue.slare_mandemo.service.serviceimpl.SlareinfoServiceImpl;
import hbue.slare_mandemo.service.serviceimpl.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.annotation.RequestScope;

import java.util.List;
import java.util.Random;

@CrossOrigin
@RestController
@RequestMapping("/user")
public class UserController {
         @Autowired
    private UserServiceImpl userA ;

         @Autowired
    SlareinfoServiceImpl slareinfoService;
         @Autowired
    DeptServiceImpl deptService ;

        //查找所有员工
         @GetMapping("/list")
    public List<Userinfo>list(){


             return userA.list();
         }

         //新增员工
    @PostMapping("/save")
    public boolean save(@RequestBody Userinfo user){
        Random random = new Random();
        int randomIntBounded = random.nextInt(10000);
             int ida = user.getId();
             String deptname =user.getDept();
             int baseslare =user.getSlare();
             Dept dept =new Dept();
        Slareinfo slareinfo =new Slareinfo();
        slareinfo.setId(ida);
        slareinfo.setSlareid(randomIntBounded);
        slareinfo.setSlareStateI("未发");
        slareinfo.setBaseSlare(baseslare);
        slareinfo.setSlareNeed(0000);
slareinfoService.save(slareinfo);
dept.setId(ida);
dept.setDeptid(randomIntBounded);
dept.setDeptname(deptname);
dept.setDeptadress("未填");
deptService.save(dept);
             return userA.save(user);
    }
//根据ID修改员工
    @PostMapping("/mod")
    public boolean mod(@RequestBody Userinfo user){

        return userA.updateById(user);
    }
//根据ID删除员工
    @GetMapping ("/delete")
    public  boolean delete(  Integer id){
        System.out.println(id);
        slareinfoService.removeById(id);
        deptService.removeById(id);
             return userA.removeById(id);
    }

//根据姓名模糊查找
    @GetMapping("/listp")
    public List<Userinfo>listp( String name){


        LambdaQueryWrapper<Userinfo> wrapper =new LambdaQueryWrapper<Userinfo>();
                     wrapper.like(Userinfo::getName,name);


        return userA.list(wrapper);
    }
//分页查询
    @PostMapping("/listpage")
    public   List<Userinfo> listpage(@RequestBody Querypageparam query){
        //打印结果
        System.out.println(query.getPagenum());

        System.out.println(query.getPagesiz());
        //1.准备分页条件
       Page<Userinfo>pagepojo = new Page();
        pagepojo.setCurrent(query.getPagenum());
       pagepojo.setSize(query.getPagesiz());
       //2。开始分页查询
       Page<Userinfo> result = userA.page(pagepojo);
        //获得结果
       long total = result.getTotal();
    long pages = result.getPages();
        System.out.println("ok");
        return  result.getRecords();
    }


}
