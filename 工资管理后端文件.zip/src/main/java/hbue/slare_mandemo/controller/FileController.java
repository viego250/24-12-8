package hbue.slare_mandemo.controller;


import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
@CrossOrigin
@RestController

public class FileController {

    @PostMapping("/upload")
    public String upload(MultipartFile file) throws IOException {

        String filename =file.getOriginalFilename();
        file.transferTo( new File("D:\\uniapp_test\\设计\\static\\files\\"+filename));
        return filename ;
    }}