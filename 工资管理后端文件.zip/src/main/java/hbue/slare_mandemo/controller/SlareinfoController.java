package hbue.slare_mandemo.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import hbue.slare_mandemo.common.Querypageparam;
import hbue.slare_mandemo.mapper.SlareinfoMapper;
import hbue.slare_mandemo.pojo.Slareinfo;
import hbue.slare_mandemo.pojo.Userinfo;
import hbue.slare_mandemo.service.serviceimpl.SlareinfoServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/slare")
public class SlareinfoController {
    @Autowired
    SlareinfoServiceImpl slareinfoService ;
@Autowired
    SlareinfoMapper slareinfoMapper;

 //返回所有工资
    @GetMapping("/SlareList")
    public List<Slareinfo> slarelist (){

        return slareinfoService.list();


    }
//增加工资号
@PostMapping("/saveSlare")
public boolean save(@RequestBody Slareinfo slareinfo){

    return slareinfoService.save(slareinfo);
}
//发放工资
@GetMapping("/pushslare")
public boolean pushslare(Integer id ,   Integer money){

      Slareinfo usea =   slareinfoService.getById(id);

        slareinfoService.pushSlare(usea,money);

    return true ;
}
//根据ID删除员工工资条例
    @GetMapping("/deleteSlare")
 public  boolean deleteSlare (Integer id){

        return slareinfoService.removeById(id);
    }
//精准查询工资条例
    @GetMapping("/selectslareId")
    public  List<Slareinfo> SelectSlareId (Integer id){




        return   slareinfoService.lambdaQuery().eq(Slareinfo::getId,id).list();

    }
//范围查找工资条例
    @GetMapping("/selectRange")
    public  List<Slareinfo> slectRange (Integer low ,Integer max){


        return  slareinfoService.lambdaQuery().ge(low!=null,Slareinfo::getBaseSlare,low)
                .le(max!=null,Slareinfo::getBaseSlare,max).list();
    }

//修改工资条例
@PostMapping("/mod")
public boolean mod(@RequestBody Slareinfo slareinfo){

    return slareinfoService.updateById(slareinfo);


}






}


































