package hbue.slare_mandemo.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import hbue.slare_mandemo.pojo.Dept;
import hbue.slare_mandemo.pojo.Slareinfo;
import hbue.slare_mandemo.pojo.Userinfo;
import hbue.slare_mandemo.service.serviceimpl.DeptServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/dept")
public class DeptController {

      @Autowired
      DeptServiceImpl deptService;


//获取列表
      @RequestMapping("/listall")

      public List<Dept> listall (){

            return  deptService.list();

      }
//增加

@PostMapping("/saveDept")
public boolean save(@RequestBody Dept dept){

      return deptService.save(dept);
}
//删除
@GetMapping("/deletedept")
public  boolean deleteSlare (Integer id){

      return deptService.removeById(id);
}
//修改
@PostMapping("/mod")
public boolean mod(@RequestBody Dept user){

      return deptService.updateById(user);
}
//查找
@GetMapping("/listp")
public List<Dept>listp( int deptid){


      LambdaQueryWrapper<Dept> wrapper =new LambdaQueryWrapper<Dept>();
      wrapper.like(Dept::getDeptid,deptid);


      return deptService.list(wrapper);
}

}
