
import DeptMange from '@/views/layoouts/DeptMange.vue'
import LayOut from '@/views/layoouts/LayOut.vue'
import SlareMange from '@/views/layoouts/SlareMange.vue'
import UserMange from '@/views/layoouts/UserMange.vue'
import { createRouter, createWebHistory } from 'vue-router'


const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      component: LayOut,
      redirect: '/usermange',

      children: [

        {
          path: '/usermange',
          component: UserMange

        },
        {
          path: '/SlareMange',
          component: SlareMange

        },
        {
          path: '/DeptMange',
          component: DeptMange

        }
      ]
    },
    {



    }
  ]
})

export default router
