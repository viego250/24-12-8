<script setup>
import { useRoute ,useRouter } from 'vue-router';
const router = useRouter()
const editSlare=()=>{
     router.push('/SlareMange')
     
}
const editUsage=()=>{
     router.push('/UserMange')
     
}
const editDept=()=>{
     router.push('/DeptMange')
     
}

</script>

<template>


<el-sub-menu index="1" >
          <template #title>
            <el-icon><Tools /></el-icon>
            <span>管理系统</span>
          </template>
          <el-menu-item-group >
            <el-menu-item index="1-1" @click="editUsage">
              <el-icon><UserFilled /></el-icon>
              人员管理
            </el-menu-item>
            <el-menu-item index="1-2"  @click="editSlare">
              <el-icon><WalletFilled /></el-icon>
              工资管理
            </el-menu-item>
            <el-menu-item index="1-3" @click="editDept">
              <el-icon><List /></el-icon>
              部门管理
            </el-menu-item>
          </el-menu-item-group>
         
        </el-sub-menu>
  


</template>

<style scoped>



</style>