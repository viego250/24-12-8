<script setup>
import SumMenu from './SumMenu.vue';
import { useCounterStore } from "@/stores/counter";

const handleOpen = () => {
 
}
const handleClose = () => {
  
}

const obj1 = useCounterStore()
</script>

<template>

<el-menu
        active-text-color="#ffd04b"
        background-color="#545c64"
          default-active="1-1"
        class="asidecont"
        text-color="#fff"
        @open="handleOpen"
        @close="handleClose"
        :collapse="obj1.iscollapse"
        :style="{width:!obj1.iscollapse?'200px':'50px'}"
       

      >
     <!-- <p  class="za">
      {{ obj1.iscollapse?'SB':'奥神个人博客' }}
     </p> -->
    <SumMenu>


    </SumMenu>
    

    </el-menu>







</template>

<style scoped lang="less">

.asidecont {


  height: 100%;
  width: 230px;
  .za{
      font-size: 20px;
      text-align: center; 
      height: 50px;
      width: 100%;
      line-height: 50px;
      color: aquamarine;

  }
}



</style>