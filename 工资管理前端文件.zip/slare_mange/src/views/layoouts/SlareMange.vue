<template>

<el-button type="primary"  @click="dialogFormVisible = true" >
 <el-icon><Plus /></el-icon>
 
    增加工资条例

  </el-button>


  <el-button type="primary"  @click="dialogFormVisible2 = true" >
 <el-icon><Promotion /></el-icon>
 
    发放工资

  </el-button>

  <el-button type="primary" @click="dialogFormVisible3 = true" >
    <el-icon><CloseBold /></el-icon>
    删除工资条例
  </el-button>

  <el-button type="primary" @click="dialogFormVisible4 = true" >
      <el-icon><Search /></el-icon>
    精确查找工资条例
  </el-button>


  <el-button type="primary" @click="dialogFormVisible5 = true" >
      <el-icon><Search /></el-icon>
    范围查找工资条例
  </el-button>

  <el-button type="primary" @click="dialogFormVisible6 = true" >
      <el-icon><Tools /></el-icon>
    修改工资条例
  </el-button>

  <el-table :data="slarelist" style="width: 100%">
    <el-table-column prop="id" label="员工ID"  />
    <el-table-column prop="slareid" label="工资号" />
    <el-table-column prop="slareNeed" label="需发工资" />
    <el-table-column prop="baseSlare" label="基础工资" />

    <el-table-column prop="slareStateI" label="工资状态" >
      
  <template #default="scope">
    
        <el-tag

        v-if="scope.row.slareStateI === '部分已发'"
          type= "warning"
          disable-transitions
          >{{ scope.row.slareStateI }}</el-tag
        >
        <el-tag

        v-if="scope.row.slareStateI === '已发'"
          type= "success"
          disable-transitions
          >{{ scope.row.slareStateI }}</el-tag
        >
        <el-tag

        v-if="scope.row.slareStateI === '未发'"
          type= "danger"
          disable-transitions
          >{{ scope.row.slareStateI }}</el-tag
        >
     
      </template>
    </el-table-column>
    
    
  </el-table>

<!-- 增加工资条例的对话框 -->

<el-dialog v-model="dialogFormVisible" title="增加工资条例" width="500">
    <el-form :model="form" ref="formref">
      <el-form-item label="id" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form.id"   placeholder="请输入员工ID"/>
      </el-form-item>

      <el-form-item label="工资号" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form.slareid"   placeholder="请输入工资号"/>
      </el-form-item>

      <el-form-item label="还需工资" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form.slareNeed"   placeholder="请输入还需要发放的工资"/>
      </el-form-item>

      <el-form-item label="基础工资" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form.baseSlare"   placeholder="请输入基础工资"/>
      </el-form-item>
      
      <el-form-item label="工资状态" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form.slareStateI"   placeholder="请输入工资状态"/>
      </el-form-item>

    </el-form>

    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取消</el-button>
        <el-button type="primary"  @click=confirm>
          确认
        </el-button>
      </div>
    </template>
  </el-dialog>





<el-dialog v-model="dialogFormVisible2" title="放发工资" width="500">
    <el-form :model="form2" ref="formref">
      <el-form-item label="id" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form2.id"   placeholder="请输入员工ID"/>
      </el-form-item>

      <el-form-item label="发放金额" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form2.money"   placeholder="请输入发放金额"/>
      </el-form-item>

      

    </el-form>

    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取消</el-button>
        <el-button type="primary"  @click=confirm2>
          确认
        </el-button>
      </div>
    </template>
  </el-dialog>

<!-- 删除工资条例的对话框 -->


<el-dialog v-model="dialogFormVisible3" title="删除工资条例" width="500">
    <el-form :model="form3" ref="formref3">
      <el-form-item label="ID" :label-width="formLabelWidth" prop="id">
        <el-input v-model="form3.id"   placeholder="请输入要删除的工资条例员工ID"/>
      </el-form-item>

      
      

    </el-form>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dialogFormVisible2 = false">取消</el-button>
        <el-button type="primary"  @click=confirm3>
          确认
        </el-button>
      </div>
    </template>
  </el-dialog>

  <!-- 精确查找工资条例 -->

<el-dialog v-model="dialogFormVisible4" title="精确查找工资条例" width="500">
    <el-form :model="form4" ref="formref4">
      <el-form-item label="ID" :label-width="formLabelWidth" prop="id">
        <el-input v-model="form4.id"   placeholder="请输入要查找的工资条例员工ID"/>
      </el-form-item>

      
      

    </el-form>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dialogFormVisible2 = false">取消</el-button>
        <el-button type="primary"  @click=confirm4>
          确认
        </el-button>
      </div>
    </template>
  </el-dialog>

    <!-- 范围查找工资条例 -->
   <el-dialog v-model="dialogFormVisible5" title=" 范围查找工资条例" width="500">
    <el-form :model="form5" ref="formref5">
      <el-form-item label="基础工资最小值" :label-width="formLabelWidth" prop="id">
        <el-input v-model="form5.low"   placeholder="请输入要查找的基础工资最小值"/>
      </el-form-item>

      
      <el-form-item label="基础工资最大值" :label-width="formLabelWidth" prop="id">
        <el-input v-model="form5.max"   placeholder="请输入要查找的基础工资最大值"/>
      </el-form-item>

    </el-form>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dialogFormVisible2 = false">取消</el-button>
        <el-button type="primary"  @click=confirm5>
          确认
        </el-button>
      </div>
    </template>
  </el-dialog>





<el-dialog v-model="dialogFormVisible6" title="修改工资条例" width="500">
    <el-form :model="form6" ref="formref">
      <el-form-item label="id" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form6.id"   placeholder="请输入员工ID"/>
      </el-form-item>

      <el-form-item label="工资号" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form6.slareid"   placeholder="请输入工资号"/>
      </el-form-item>

      <el-form-item label="还需工资" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form6.slareNeed"   placeholder="请输入还需要发放的工资"/>
      </el-form-item>

      <el-form-item label="基础工资" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form6.baseSlare"   placeholder="请输入基础工资"/>
      </el-form-item>
      
     <el-form-item label="工资状态" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form6.slareStateI"   placeholder="请输入工资状态"/>
      </el-form-item>
    </el-form>

    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dialogFormVisible6 = false">取消</el-button>
        <el-button type="primary"  @click=confirm6>
          确认
        </el-button>
      </div>
    </template>
  </el-dialog>


</template>

<script setup>
import { onMounted, reactive, ref } from 'vue';
import axios from 'axios';



const dialogFormVisible =ref(false)
 const dialogFormVisible2 =ref(false)
const dialogFormVisible3 =ref(false)
const dialogFormVisible4  =ref(false)
const dialogFormVisible5  =ref(false)
const dialogFormVisible6  =ref(false)

const form = reactive({

    id:"",
    slareid:"",
    slareNeed:"",
    baseSlare:"",
    slareStateI:"",

})

const form2 =ref({

 id:"",
 money:""

})

const form3 =ref({

  id:""
})

const form4 =ref({

  id:""
})
const form5 =ref({


  low:"",
  max:""
})

const form6 = reactive({

    id:"",
    slareid:"",
    slareNeed:"",
    baseSlare:"",
    slareStateI:"",
    

})


const slarelist =ref([])

onMounted(()=>{

    getlist()

})
const formLabelWidth =ref(150)
const getlist =async()=>{
 
      const res =await axios ({

        method:"Get",
        url:"http://localhost:8080/slare/SlareList"
      })

      slarelist.value =res.data
        

      

}

const confirm=()=>{

dialogFormVisible.value = false

//通过axios增加一个员工数据
axios.post("http://localhost:8080/slare/saveSlare",form



).then(()=>{   
  console.log("99992")
        getlist()  ;
})


}


const confirm2=()=>{

dialogFormVisible2.value = false

//通过axios增加一个员工数据
// http://localhost:8080/slare/pushslare?id=354&money=90000000
axios.get("http://localhost:8080/slare/pushslare?id="+ form2.value.id+  "&money="+form2.value.money



).then(()=>{   
  console.log("99992")
        getlist()  ;
})




}

const confirm3=()=>{

dialogFormVisible3.value = false

//通过axios删除一个员工数据
axios.get("http://localhost:8080/slare/deleteSlare?id="+form3.value.id



).then(()=>{   
getlist()
})
}


const confirm4=()=>{

dialogFormVisible4.value = false

//通过axios查找一个员工数据
axios.get("http://localhost:8080/slare/selectslareId?id="+form4.value.id



).then((res)=>{   
  //  console.log(res)
  slarelist.value =res.data

})
}



const confirm5=()=>{

dialogFormVisible5.value = false

//通过axios查找一个员工数据
axios.get("http://localhost:8080/slare/selectRange?low="+form5.value.low+"&"+"max="+form5.value.max



).then((res)=>{   
  //  console.log(res)
  slarelist.value =res.data

})
}



const confirm6=()=>{

dialogFormVisible6.value = false
//写一个修改的axios

axios.post("http://localhost:8080/slare/mod",form6).then(()=>{   
getlist()
});


}


</script>

<style>




</style>