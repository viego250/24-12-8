<script setup>
import { RouterLink, RouterView } from 'vue-router'
import AsiDeone from '@/components/AsiDeone.vue'
import HeaDer from './HeaDer.vue';
import axios from 'axios';



</script>
<template>



  <div class="common-layout"  >
    <el-container >
      <el-header ><HeaDer></HeaDer></el-header>
      <el-container >
        <el-aside width="200px" > <AsiDeone></AsiDeone></el-aside>
        <el-main ><RouterView></RouterView></el-main>
      </el-container>
    </el-container>
  </div>

</template>

<style scoped lang="less">

.common-layout {


  height: 100%;
  .el-container {

    height: 100%;
  }
}

</style>