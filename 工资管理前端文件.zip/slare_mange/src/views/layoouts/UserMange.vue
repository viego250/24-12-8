<script setup>
import { reactive, ref } from 'vue'
import axios from 'axios';
import {onMounted} from 'vue'






const paginationdata =reactive({

  pagenum:1,
  pagesiz:5
})

const form = reactive({
  name: "",
  title:"",
  dept:"",
    slare:"",
    id: 1
  
})

const form2 = reactive({
  id : ""
  
})
const total =ref(100)
const dialogFormVisible = ref(false)
const dialogFormVisible2 = ref(false)
const dialogFormVisible4 = ref(false)
const formLabelWidth = '140px'
const dialogFormVisible3=ref(false)

const form3=ref({
  name:""
})

const form4=ref({
  id:"",
  name:""
})

const userlist = ref([])
onMounted(() => {
  getpage()
})

const getpage =async()=>{

  const res = await axios({
       method: "post",
       url:"http://localhost:8080/user/listpage",
       data:{
            pagenum:paginationdata.pagenum,
            pagesiz:paginationdata.pagesiz

       }
  })
   userlist.value = res.data
  
  console.log("拿到页面参数")
}



// axios.get("http://localhost:8080/user/list").then((res)=>{

// userlist.value = res.data;

// })

 const   getlist=async()=>{
   const res = await axios({

        method:"get",
        url:"http://localhost:8080/user/list"

   })
  userlist.value = res.data;
  console.log("getlist被调用")

 }
 

 




const confirm=()=>{

dialogFormVisible.value = false

//通过axios增加一个员工数据
axios.post("http://localhost:8080/user/save",form



).then(()=>{   
getpage();
})


}


const confirm2=()=>{

dialogFormVisible2.value = false

//通过axios删除一个员工数据
axios.get("http://localhost:8080/user/delete?id="+form2.id



).then(()=>{   
getpage()
})

  
}
const confirm3=()=>{

dialogFormVisible3.value = false

//通过axios查找一个员工数据
axios.get("http://localhost:8080/user/listp?name="+form3.value.name



).then((res)=>{  
  console.log(res)
  userlist.value = res.data 

// getpage()
})
}
const confirm4=()=>{

dialogFormVisible4.value = false

//通过axios删除一个员工数据
axios.post("http://localhost:8080/user/mod",{
id:form4.value.id,
name:form4.value.name

}



).then((res)=>{  
 

 getpage()
})
  
}


const handleSizeChange = (val) => {
  paginationdata.pagesiz=val
   getpage()
}
const handleCurrentChange = (val) => {
  paginationdata.pagenum=val
   getpage()
}


</script>

<template>


<div>


<el-button type="primary"  @click="dialogFormVisible = true" >
 <el-icon><Plus /></el-icon>
 
    增加人员

  </el-button>

  <el-button type="primary" @click="dialogFormVisible2 = true" >
    <el-icon><CloseBold /></el-icon>
    删除人员
  </el-button>

<el-button type="primary" @click="dialogFormVisible4 = true" >
  <el-icon><Orange /></el-icon>
    编辑人员资料
  </el-button>

  <el-button type="primary" @click="dialogFormVisible3 = true" >
   <el-icon><Search /></el-icon>
    查找人员
  </el-button>

<el-table :data="userlist" style="width: 100%">
    <el-table-column prop="id" label="员工ID" width="180" />
    <el-table-column prop="name" label="姓名" width="180" />
    <el-table-column prop="title" label="职称" width="180" />
     <el-table-column prop="dept" label="部门" width="180" />
      <el-table-column prop="slare" label="工资" width="180" />
  </el-table>






<el-dialog v-model="dialogFormVisible2" title="删除员工" width="500">
    <el-form :model="form2" ref="formref2">
      <el-form-item label="ID" :label-width="formLabelWidth" prop="id">
        <el-input v-model="form2.id"   placeholder="请输入要删除的员工ID"/>
      </el-form-item>

      
      

    </el-form>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dialogFormVisible2 = false">取消</el-button>
        <el-button type="primary"  @click=confirm2>
          确认
        </el-button>
      </div>
    </template>
  </el-dialog>



  <el-dialog v-model="dialogFormVisible3" title="查找员工" width="500">
    <el-form :model="form3" ref="formref3">
      <el-form-item label="模糊查找" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form3.name"   placeholder="请输入要查找的员工含有的名字"/>
      </el-form-item>
    </el-form>

    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dialogFormVisible3 = false">取消</el-button>
        <el-button type="primary"  @click=confirm3>
          确认
        </el-button>
      </div>
    </template>
  </el-dialog>



  <el-dialog v-model="dialogFormVisible4" title="编辑员工" width="500">
    <el-form :model="form4" ref="formref4">
      <el-form-item label="ID" :label-width="formLabelWidth" prop="id">
        <el-input v-model="form4.id"   placeholder="请输入要编辑的员工ID"/>
      </el-form-item> 
               <p style="text-align: center ; color: red;"> 如需修改其他数据请前往其他管理模块</p>
      <el-form-item label="name" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form4.name"   placeholder="请输入要编员工的新姓名"/>
      </el-form-item>
      

    </el-form>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dialogFormVisible2 = false">取消</el-button>
        <el-button type="primary"  @click=confirm4>
          确认
        </el-button>
      </div>
    </template>
  </el-dialog>


<el-dialog v-model="dialogFormVisible" title="增加员工" width="500">
    <el-form :model="form" ref="formref">

    <el-form-item label="员工ID" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form.id"   placeholder="请输入ID"/>
      </el-form-item>


      <el-form-item label="姓名" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form.name"   placeholder="请输入姓名"/>
      </el-form-item>

      <el-form-item label="职称" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form.title"   placeholder="请输入职称"/>
      </el-form-item>

      <el-form-item label="部门" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form.dept"   placeholder="请输入部门"/>
      </el-form-item>

      <el-form-item label="工资" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form.slare"   placeholder="请输入工资"/>
      </el-form-item>
      
      

    </el-form>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取消</el-button>
        <el-button type="primary"  @click=confirm>
          确认
        </el-button>
      </div>
    </template>
  </el-dialog>


<div >

    <el-pagination
    class="pageclass"
      v-model:current-page="paginationdata.pagenum"
      :page-size="paginationdata.pagesiz"
      background
      layout=" prev, pager, next"
     :total="50"
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
    />
  </div>



</div>



</template>

<style scoped>
.pageclass {


  margin-top: 20px;
  margin-left: 5px
}


</style>