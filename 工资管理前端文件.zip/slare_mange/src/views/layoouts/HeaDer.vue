<script setup>
import { useCounterStore } from "@/stores/counter";
const obj2 = useCounterStore()


</script>

<template>

<div >

 <div  >  
  <el-icon class="icon" size="30" @click="obj2.chagecollapse"><Fold /></el-icon>
 
    
 </div>

 <!-- <div style="flex:1;text-align:center;font-size: 34px;"><span>工资管理系统</span></div> -->
 

 
</div>

</template>

<style scoped>



</style>