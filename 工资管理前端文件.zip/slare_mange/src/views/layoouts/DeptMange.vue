<template>
<el-button type="primary"  @click="dialogFormVisible = true" >
 <el-icon><Plus /></el-icon>
 
    增加部门条例

  </el-button>

<el-button type="primary" @click="dialogFormVisible2 = true" >
    <el-icon><CloseBold /></el-icon>
    删除部门条例
  </el-button>

<el-button type="primary" @click="dialogFormVisible3 = true" >
 <el-icon><Orange /></el-icon>
    修改部门条例
  </el-button>


<el-button type="primary" @click="dialogFormVisible4 = true" >
 <el-icon><Search /></el-icon>
    查找部门条例
  </el-button>


<el-table :data="deptlist" style="width: 100%">
    <el-table-column prop="id" label="员工ID" width="180" />
    <el-table-column prop="deptid" label="部门邮编" width="180" />
    <el-table-column prop="deptname" label="部门名称" width="180" />
     <el-table-column prop="deptadress" label="部门地址" width="180" />    
  </el-table>



 <!-- 增加部门条例 -->
<el-dialog v-model="dialogFormVisible" title="增加部门条例" width="500">
    <el-form :model="form" ref="formref">
      <el-form-item label="id" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form.id"   placeholder="请输入员工ID"/>
      </el-form-item>

      <el-form-item label="部门邮编" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form.deptid"   placeholder="请输入部门邮编"/>
      </el-form-item>

      <el-form-item label="部门名称" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form.deptname"   placeholder="请输入部门名称"/>
      </el-form-item>

      <el-form-item label="部门地址" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form.deptadress"   placeholder="请输入部门地址"/>
      </el-form-item>
      
      

    </el-form>

    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取消</el-button>
        <el-button type="primary"  @click=confirm>
          确认
        </el-button>
      </div>
    </template>
  </el-dialog>
<!-- 删除部门条例 -->
<el-dialog v-model="dialogFormVisible2" title="删除部门条例" width="500">
    <el-form :model="form2" ref="formref2">
      <el-form-item label="ID" :label-width="formLabelWidth" prop="id">
        <el-input v-model="form2.id"   placeholder="请输入要删除的部门条例员工ID"/>
      </el-form-item>

      
      

    </el-form>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dialogFormVisible2 = false">取消</el-button>
        <el-button type="primary"  @click=confirm2>
          确认
        </el-button>
      </div>
    </template>
  </el-dialog>

<!-- 修改部门条例 -->
<el-dialog v-model="dialogFormVisible3" title="修改部门条例" width="500">
    <el-form :model="form3" ref="formref">
      <el-form-item label="id" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form3.id"   placeholder="请输入员工ID"/>
      </el-form-item>

      <el-form-item label="部门邮编" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form3.deptid"   placeholder="请输入部门邮编"/>
      </el-form-item>

      <el-form-item label="部门名称" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form3.deptname"   placeholder="请输入部门名称"/>
      </el-form-item>

      <el-form-item label="部门地址" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form3.deptadress"   placeholder="请输入部门地址"/>
      </el-form-item>
      
      

    </el-form>

    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dialogFormVisible3 = false">取消</el-button>
        <el-button type="primary"  @click=confirm3>
          确认
        </el-button>
      </div>
    </template>
  </el-dialog>


<!-- 查找部门条例 -->
<el-dialog v-model="dialogFormVisible4" title="查找部门条例" width="500">
    <el-form :model="form4" ref="formref">
      <el-form-item label="部门邮编" :label-width="formLabelWidth" prop="name">
        <el-input v-model="form4.deptid"   placeholder="请输入部门邮编含有字段"/>
      </el-form-item>

      

    </el-form>

    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dialogFormVisible4 = false">取消</el-button>
        <el-button type="primary"  @click=confirm4>
          确认
        </el-button>
      </div>
    </template>
  </el-dialog>

</template>

<script setup>
import { onMounted, ref } from 'vue';
import axios from 'axios';


const deptlist =ref([])

const formLabelWidth =ref(150)

const dialogFormVisible =ref(false)
const dialogFormVisible2 =ref(false)
const dialogFormVisible3 =ref(false)
const dialogFormVisible4 =ref(false)


const form =ref({

id:"",
deptid:"",
deptname:"",
deptadress:""

})

const form2 =ref({
id:""

})
const form3 =ref({

id:"",
deptid:"",
deptname:"",
deptadress:""

})
const form4 =ref({


deptid:""



})
onMounted(()=>{

    getlist()

})

const getlist =async()=>{
 
      const res =await axios ({

        method:"Get",
        url:"http://localhost:8080/dept/listall"
      })

      deptlist.value =res.data
        

      

}


const confirm=()=>{

dialogFormVisible.value = false

//通过axios增加一个员工数据
axios.post("http://localhost:8080/dept/saveDept",form.value



).then(()=>{   
  console.log("99992")
        getlist()  ;
})
}

const confirm2=()=>{

dialogFormVisible2.value = false

//通过axios删除一个员工数据
axios.get("http://localhost:8080/dept/deletedept?id="+form2.value.id



).then(()=>{   
getlist()
})
}
const confirm3=()=>{

dialogFormVisible3.value = false

//通过axios修改一个员工数据
axios.post("http://localhost:8080/dept/mod",form3.value



).then(()=>{   
getlist()
})
}

const confirm4=()=>{

dialogFormVisible4.value = false

//通过axios查找一个部门数据
axios.get("http://localhost:8080/dept/listp?deptid="+form4.value.deptid).then((res)=>{  
  
  deptlist.value = res.data

})

}
</script>

<style>




</style>