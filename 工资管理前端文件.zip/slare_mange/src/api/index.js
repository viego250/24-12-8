import instance from "@/utils/request";

//获取员工列表数据


export const getlist=()=>{

  return instance.get('/list')
}